winapi
======

Windows API declarations without &lt;windows.h>, for internal Boost use.

### License

Distributed under the [Boost Software License, Version 1.0](http://boost.org/LICENSE_1_0.txt).
